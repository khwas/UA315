Put the UTFT and UTouch folder into the IDE1.5.6 libraries folder. Then run IDE. 
Open the File/Examples/UTouch/Arduino/UTouch_Calibration.ino .  Download theino file into the DUE ,Then reset the board  The graphics could be seen then.
