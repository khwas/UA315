Put the UTFT folder into the IDE1.5.6 libraries folder. Then run IDE. 
Open the File /Examples/UTFT/Arduino��AVR��/UTFT_Demo_480X272.ino .  Download theino file into the MEGA ,Then reset the board  The graphics could be seen then.
